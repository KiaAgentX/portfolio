// content.js — روی هر صفحه اجرا می‌شود.
// قیمت‌های دلاری را در متن صفحه پیدا می‌کند و معادل تومانی را با رنگ سبز
// کنار آن نمایش می‌دهد.

(function () {
  "use strict";

  let rate = null; // نرخ هر دلار به تومان
  const PROCESSED_ATTR = "data-usd-toman-done";
  const TAG_CLASS = "usd-toman-tag";
  const WRAP_CLASS = "usd-toman-wrap";

  // الگوی تشخیص مبلغ دلاری:
  //  $10 , $1,234.56 , 10$ , 10 USD , USD 10 , US$ 10
  // گروه عدد در هر دو حالت گرفته می‌شود.
  const DOLLAR_REGEX = new RegExp(
    [
      "(?:US\\$|USD\\$?|\\$)\\s?(\\d{1,3}(?:[,\\u066c]\\d{3})*(?:[.\\u066b]\\d+)?|\\d+(?:[.\\u066b]\\d+)?)", // $10
      "(\\d{1,3}(?:[,\\u066c]\\d{3})*(?:[.\\u066b]\\d+)?|\\d+(?:[.\\u066b]\\d+)?)\\s?(?:US\\$|USD|\\$)" // 10$ یا 10 USD
    ].join("|"),
    "gi"
  );

  // تگ‌هایی که نباید داخلشان دست بزنیم
  const SKIP_TAGS = new Set([
    "SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA", "INPUT", "SELECT",
    "OPTION", "CODE", "PRE", "KBD"
  ]);

  function parseAmount(str) {
    // تبدیل اعشار و جداکننده فارسی/انگلیسی به عدد استاندارد
    const normalized = str
      .replace(/[٬,]/g, "") // جداکننده هزارگان
      .replace(/[٫]/g, "."); // اعشار فارسی
    return parseFloat(normalized);
  }

  function formatToman(amount) {
    const toman = Math.round(amount * rate);
    return toman.toLocaleString("fa-IR") + " تومان";
  }

  function makeTag(amount) {
    const span = document.createElement("span");
    span.className = TAG_CLASS;
    span.textContent = "≈ " + formatToman(amount);
    span.title = "نرخ هر دلار: " + rate.toLocaleString("fa-IR") + " تومان";
    span.dir = "rtl";
    return span;
  }

  // یک گره متنی را پردازش می‌کند: اگر مبلغ دلاری داشت، آن را در یک span
  // علامت‌گذاری‌شده می‌پیچد و تگ تومان را کنارش می‌گذارد.
  // پیچیدن قیمت اصلی باعث می‌شود در اسکن‌های بعدی دوباره پردازش نشود
  // (جلوگیری از باگ تکرار بی‌نهایت).
  function processTextNode(node) {
    const text = node.nodeValue;
    if (!text || text.length > 2000) return;

    DOLLAR_REGEX.lastIndex = 0;
    if (!DOLLAR_REGEX.test(text)) return;

    DOLLAR_REGEX.lastIndex = 0;
    const frag = document.createDocumentFragment();
    let lastIndex = 0;
    let match;
    let found = false;

    while ((match = DOLLAR_REGEX.exec(text)) !== null) {
      const amountStr = match[1] || match[2];
      const amount = parseAmount(amountStr);
      const matchText = match[0];
      const end = match.index + matchText.length;

      // متن قبل از مبلغ (دست‌نخورده)
      if (match.index > lastIndex) {
        frag.appendChild(
          document.createTextNode(text.slice(lastIndex, match.index))
        );
      }

      if (!isNaN(amount) && amount > 0 && rate) {
        // قیمت اصلی + تگ تومان داخل یک wrapper علامت‌گذاری‌شده
        const wrap = document.createElement("span");
        wrap.className = WRAP_CLASS;
        wrap.setAttribute(PROCESSED_ATTR, "1");
        wrap.appendChild(document.createTextNode(matchText));
        wrap.appendChild(makeTag(amount));
        frag.appendChild(wrap);
        found = true;
      } else {
        frag.appendChild(document.createTextNode(matchText));
      }
      lastIndex = end;
    }

    if (!found) return; // چیز معتبری پیدا نشد، دست نزن
    if (lastIndex < text.length) {
      frag.appendChild(document.createTextNode(text.slice(lastIndex)));
    }

    const parent = node.parentNode;
    if (parent) parent.replaceChild(frag, node);
  }

  function shouldSkip(el) {
    if (!el) return true;
    if (SKIP_TAGS.has(el.tagName)) return true;
    if (el.isContentEditable) return true;
    // هرچیزی داخل تگ تومان یا wrapper علامت‌گذاری‌شده را رد کن
    if (el.closest && el.closest("." + TAG_CLASS + ", ." + WRAP_CLASS)) {
      return true;
    }
    return false;
  }

  function scan(root) {
    if (!rate) return;
    const walker = document.createTreeWalker(
      root,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          const parent = node.parentElement;
          if (shouldSkip(parent)) return NodeFilter.FILTER_REJECT;
          if (!node.nodeValue || !node.nodeValue.trim()) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );

    const nodes = [];
    let n;
    while ((n = walker.nextNode())) nodes.push(n);
    nodes.forEach(processTextNode);
  }

  // مشاهده تغییرات صفحه (محتوای داینامیک / SPA)
  let scanScheduled = false;
  const pendingRoots = new Set();

  function scheduleScan(root) {
    pendingRoots.add(root || document.body);
    if (scanScheduled) return;
    scanScheduled = true;
    requestIdleCallback(() => {
      scanScheduled = false;
      const roots = Array.from(pendingRoots);
      pendingRoots.clear();
      roots.forEach((r) => {
        if (r && r.nodeType === Node.ELEMENT_NODE) scan(r);
      });
    });
  }

  const observer = new MutationObserver((mutations) => {
    for (const m of mutations) {
      for (const added of m.addedNodes) {
        if (added.nodeType === Node.ELEMENT_NODE) {
          // افزوده‌های خودِ اکستنشن را نادیده بگیر
          if (
            added.classList &&
            (added.classList.contains(TAG_CLASS) ||
              added.classList.contains(WRAP_CLASS))
          ) {
            continue;
          }
          scheduleScan(added);
        } else if (added.nodeType === Node.TEXT_NODE) {
          scheduleScan(added.parentElement || document.body);
        }
      }
    }
  });

  function startObserving() {
    if (document.body) {
      observer.observe(document.body, { childList: true, subtree: true });
    }
  }

  // requestIdleCallback fallback
  if (typeof window.requestIdleCallback !== "function") {
    window.requestIdleCallback = (cb) => setTimeout(() => cb({ timeRemaining: () => 50 }), 200);
  }

  // گرفتن نرخ از background سپس اولین اسکن
  function init() {
    chrome.runtime.sendMessage({ type: "GET_RATE" }, (response) => {
      if (chrome.runtime.lastError) return;
      if (response && response.rate && response.rate.toman) {
        rate = response.rate.toman;
        scan(document.body);
        startObserving();
      }
    });
  }

  // اگر نرخ به‌روز شد، صفحه را دوباره با مقدار جدید رنگ نمی‌زنیم
  // (برای سادگی فقط در بارگذاری بعدی اعمال می‌شود).
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.usdTomanRate) {
      const newRate = changes.usdTomanRate.newValue;
      if (newRate && newRate.toman) rate = newRate.toman;
    }
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
