// popup.js — نمایش نرخ فعلی، دکمه به‌روزرسانی و ثبت نرخ دستی

const rateValue = document.getElementById("rateValue");
const meta = document.getElementById("meta");
const refreshBtn = document.getElementById("refresh");
const manualInput = document.getElementById("manualInput");
const setManualBtn = document.getElementById("setManual");

function render(rate) {
  if (!rate || !rate.toman) {
    rateValue.textContent = "خطا";
    meta.textContent = "نرخ در دسترس نیست. اتصال اینترنت یا نرخ دستی را بررسی کنید.";
    return;
  }
  rateValue.textContent = rate.toman.toLocaleString("fa-IR");
  const date = new Date(rate.updatedAt);
  const time = date.toLocaleTimeString("fa-IR");
  const srcLabel = rate.source === "manual" ? "دستی" : rate.source;
  meta.textContent = `منبع: ${srcLabel} • آخرین به‌روزرسانی: ${time}`;
}

function load(forceRefresh = false) {
  meta.textContent = "در حال بارگذاری…";
  chrome.runtime.sendMessage({ type: "GET_RATE", forceRefresh }, (response) => {
    if (chrome.runtime.lastError) {
      meta.textContent = "خطا در ارتباط با اکستنشن.";
      return;
    }
    render(response && response.rate);
  });
}

refreshBtn.addEventListener("click", () => load(true));

setManualBtn.addEventListener("click", () => {
  const val = parseInt(manualInput.value, 10);
  if (!val || val < 1000) {
    manualInput.style.borderColor = "#dc2626";
    return;
  }
  chrome.runtime.sendMessage(
    { type: "SET_MANUAL_RATE", toman: val },
    (response) => {
      if (response && response.rate) {
        render(response.rate);
        manualInput.value = "";
        manualInput.style.borderColor = "#334155";
      }
    }
  );
});

load();
