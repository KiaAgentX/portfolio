// background.js — سرویس‌ورکر اکستنشن
// وظیفه: گرفتن نرخ لحظه‌ای دلار بازار آزاد ایران (به تومان) از API رایگان،
// کش کردن آن و پاسخ به درخواست‌های content script و popup.

const CACHE_KEY = "usdTomanRate";
const REFRESH_MINUTES = 10; // هر ۱۰ دقیقه نرخ به‌روز می‌شود

// منابع رایگان به ترتیب اولویت. هر منبع یک تابع parse دارد که خروجی را به
// «تومان» تبدیل می‌کند.
const SOURCES = [
  {
    // منبع لحظه‌ای (live) — قیمت همان لحظه بازار
    name: "tgju-live",
    url: "https://call.tgju.org/ajax.json",
    parse: (data) => {
      const raw = data?.current?.price_dollar_rl?.p;
      const rial = toNumber(raw);
      if (!rial) return null;
      return normalizeToToman(rial); // ریال -> تومان
    }
  },
  {
    // منبع پشتیبان مطمئن — آخرین نرخ بسته‌شدن دلار آزاد (به ریال)
    name: "tgju-table",
    url: "https://api.tgju.org/v1/market/indicator/summary-table-data/price_dollar_rl",
    parse: (data) => {
      // data.data آرایه‌ای نزولی از روزهاست؛ ردیف اول جدیدترین است.
      // فرمت هر ردیف: [close, low, high, open, change, pct, gdate, jdate]
      const latest = data?.data?.[0]?.[0];
      const rial = toNumber(latest);
      if (!rial) return null;
      return normalizeToToman(rial); // ریال -> تومان
    }
  }
];

function toNumber(value) {
  if (value === null || value === undefined) return NaN;
  // حذف کاما، فاصله و کاراکترهای غیرعددی به‌جز نقطه
  const cleaned = String(value).replace(/[,\s]/g, "").replace(/[^\d.]/g, "");
  return parseFloat(cleaned);
}

// اگر عدد در محدوده ریال باشد (مثلاً > ۲۰۰٬۰۰۰) به تومان تبدیل می‌کنیم.
function normalizeToToman(n) {
  if (n > 200000) return Math.round(n / 10);
  return Math.round(n);
}

async function fetchRate() {
  for (const source of SOURCES) {
    try {
      const res = await fetch(source.url, { cache: "no-store" });
      if (!res.ok) continue;
      const data = await res.json();
      const toman = source.parse(data);
      if (toman && toman > 1000) {
        const payload = {
          toman,
          source: source.name,
          updatedAt: Date.now()
        };
        await chrome.storage.local.set({ [CACHE_KEY]: payload });
        return payload;
      }
    } catch (err) {
      // سراغ منبع بعدی می‌رویم
      console.warn(`[Dollar->Toman] منبع ${source.name} ناموفق:`, err);
    }
  }
  return null;
}

async function getRate(forceRefresh = false) {
  const stored = (await chrome.storage.local.get(CACHE_KEY))[CACHE_KEY];
  const isFresh =
    stored && Date.now() - stored.updatedAt < REFRESH_MINUTES * 60 * 1000;

  if (stored && isFresh && !forceRefresh) return stored;

  const fresh = await fetchRate();
  if (fresh) return fresh;

  // اگر گرفتن نرخ ناموفق بود ولی نسخه قدیمی داریم، همان را بده.
  return stored || null;
}

// راه‌اندازی آلارم برای به‌روزرسانی دوره‌ای
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("refreshRate", { periodInMinutes: REFRESH_MINUTES });
  fetchRate();
});
chrome.runtime.onStartup.addListener(() => {
  fetchRate();
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "refreshRate") fetchRate();
});

// پاسخ به پیام‌ها از content script و popup
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "GET_RATE") {
    getRate(message.forceRefresh).then((rate) => sendResponse({ rate }));
    return true; // async response
  }
  if (message?.type === "SET_MANUAL_RATE") {
    const payload = {
      toman: message.toman,
      source: "manual",
      updatedAt: Date.now()
    };
    chrome.storage.local.set({ [CACHE_KEY]: payload }).then(() =>
      sendResponse({ rate: payload })
    );
    return true;
  }
});
